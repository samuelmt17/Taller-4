package gui;

import juego.LightsOut;
import juego.LightsOutBoard;
import juego.LightsOutScore;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.RoundRectangle2D;

import javax.swing.JPanel;

public class LightsOutGUI {
    private JFrame frame;
    private LightsOutBoard board;
    private LightsOutScore score;
    private JLabel[][] cells;
    private JLabel statusLabel;
    private JLabel movesLabel;
    private JComboBox<Integer> sizeSelector;
    private JRadioButton randomSelector;
    private JRadioButton presetSelector;
    private JButton newGameButton;
    private JButton highScoresButton;

    public LightsOutGUI() {
        // Crear el juego y el sistema de puntuación
        this.board = new LightsOutBoard(5);
        this.score = new LightsOut



public class LightsOutCell extends JPanel implements MouseListener, MouseMotionListener {

    private static final long serialVersionUID = 1L;
    private static final int CELL_SIZE = 50;
    private static final Color COLOR_ON = new Color(255, 220, 128);
    private static final Color COLOR_OFF = new Color(80, 80, 80);
    private static final Color COLOR_HOVER_ON = new Color(255, 240, 160);
    private static final Color COLOR_HOVER_OFF = new Color(120, 120, 120);
    private static final Color COLOR_TEXT = Color.WHITE;
    private static final Color COLOR_TEXT_HOVER = new Color(70, 70, 70);
    private static final Color COLOR_TEXT_PRESSED = new Color(200, 200, 200);
    private static final int ARC_SIZE = 10;

    private boolean isOn;
    private int clickCount;

    public LightsOutCell() {
        this.isOn = false;
        this.clickCount = 0;
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        this.setOpaque(false);
    }

    public void toggle() {
        isOn = !isOn;
        clickCount++;
        repaint();
    }

    public boolean isOn() {
        return isOn;
    }

    public void setIsOn(boolean isOn) {
        this.isOn = isOn;
        repaint();
    }

    public int getClickCount() {
        return clickCount;
    }

    public void setClickCount(int clickCount) {
        this.clickCount = clickCount;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g.create();

        // Set rendering hints
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Color de fondo con gradiente
        GradientPaint backgroundGradient;
        if (isOn) {
            backgroundGradient = new GradientPaint(0, 0, COLOR_ON, getWidth(), getHeight(), COLOR_ON.darker());
        } else {
            backgroundGradient = new GradientPaint(0, 0, COLOR_OFF, getWidth(), getHeight(), COLOR_OFF.darker());
        }
        g2d.setPaint(backgroundGradient);

        // Dibuja rounded rectangle con gradiente
        RoundRectangle2D roundedRectangle = new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), ARC_SIZE, ARC_SIZE);
        g2d.fill(roundedRectangle);

        // Color de texto
        Color textColor;
        if (isOn) {
            textColor = COLOR_TEXT;
        } else {
            textColor = COLOR_TEXT_HOVER;
        }
        if (clickCount > 0 && !isOn) {
            textColor = COLOR_TEXT_PRESSED;
        }

    public class LightsOutBoardGUI extends JPanel implements MouseListener {
    

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;
        int cellSize = calculateCellSize();

        for (int row = 0; row < board.getSize(); row++) {
            for (int col = 0; col < board.getSize(); col++) {
                int x = col * cellSize;
                int y = row * cellSize;
                boolean isOn = board.isLit(row, col);

                // dibujar el rectángulo con esquinas redondeadas
                g2d.setPaint(getCellPaint(row, col));
                g2d.fillRoundRect(x, y, cellSize, cellSize, 10, 10);

                // dibujar el número de veces que se ha presionado la casilla
                String text = Integer.toString(board.getPresses(row, col));
                FontMetrics fm = g.getFontMetrics();
                int textWidth = fm.stringWidth(text);
                int textHeight = fm.getHeight();
                int textX = x + (cellSize - textWidth) / 2;
                int textY = y + (cellSize + textHeight) / 2;
                g.setColor(Color.BLACK);
                g.drawString(text, textX, textY);

                // dibujar el borde de la casilla
                g.setColor(Color.BLACK);
                g.drawRoundRect(x, y, cellSize, cellSize, 10, 10);
            }
        }
    }

		@Override
	public void mousePressed(MouseEvent e)
	{
	int click_x = e.getX();
	int click_y = e.getY();
	int[] casilla = convertirCoordenadasACasilla(click_x, click_y);
	cantidades[casilla[0]][casilla[1]]++;
	principal.jugar(casilla[0], casilla[1]);
	this.ultima_fila = casilla[0];
	this.ultima_columna = casilla[1];
	repaint();
	}
	private int[] convertirCoordenadasACasilla(int x, int y)
	{
	int ladoTablero = tablero.length;
	int altoPanelTablero = getHeight();
	int anchoPanelTablero = getWidth();
	int altoCasilla = altoPanelTablero / ladoTablero;
	int anchoCasilla = anchoPanelTablero / ladoTablero;
	int fila = (int) (y / altoCasilla);
	int columna = (int) (x / anchoCasilla);
	return new int[] { fila, columna };
	}

JButton reiniciarButton = new JButton("Reiniciar");
reiniciarButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Lógica para reiniciar el tablero
        tablero.inicializar();
        repaint();
    }
});

}




