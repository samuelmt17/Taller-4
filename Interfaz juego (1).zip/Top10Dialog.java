import java.awt.Color;
import java.awt.Component;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class Top10CellRenderer extends DefaultListCellRenderer implements ListCellRenderer<Object[]> {

    @Override
    public Component getListCellRendererComponent(JList<? extends Object[]> list, Object[] value, int index,
            boolean isSelected, boolean cellHasFocus) {

        JLabel cell = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

        // Personaliza la visualización del elemento del JList
        cell.setText(String.format("%d. %s - %d movimientos", index + 1, value[0], value[1]));
        cell.setBackground(index % 2 == 0 ? Color.WHITE : Color.LIGHT_GRAY);

        return cell;
    }
}

public class Top10ListModel implements ListModel<String> {
    private ArrayList<String> scores;

    public Top10ListModel(ArrayList<String> scores) {
        this.scores = scores;
    }

    @Override
    public int getSize() {
        return scores.size();
    }

    @Override
    public String getElementAt(int index) {
        return scores.get(index);
    }

    @Override
    public void addListDataListener(ListDataListener listener) {
    }

    @Override
    public void removeListDataListener(ListDataListener listener) {
    }
}

public class Top10Dialog extends JDialog {
    private JList<String> top10List;

    public Top10Dialog(JFrame parentFrame) {
        super(parentFrame, "Top 10", true);

        // obtener los resultados del Top10
        ArrayList<String> top10Scores = getTop10Scores();

        // crear el modelo de lista personalizado
        Top10ListModel listModel = new Top10ListModel(top10Scores);

        // crear la lista con el modelo personalizado
        top10List = new JList<>(listModel);

        // personalizar la apariencia de la lista
        top10List.setCellRenderer(new MyListCellRenderer());

        // añadir la lista a un JScrollPane
        JScrollPane scrollPane = new JScrollPane(top10List);

        // añadir el JScrollPane al diálogo
        add(scrollPane);

        // establecer el tamaño del diálogo
        setSize(300, 300);

        // centrar el diálogo en la pantalla
        setLocationRelativeTo(null);
    }

    private ArrayList<String> getTop10Scores() {
        // código para obtener los resultados del Top10
        // y devolverlos como una lista de strings
    }
}

class MyListCellRenderer extends DefaultListCellRenderer {
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        // obtener el componente de renderizado por defecto
        JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

        // personalizar el aspecto del componente
        // por ejemplo, cambiar el color de fondo y el tipo de letra

        return label;
    }
}
