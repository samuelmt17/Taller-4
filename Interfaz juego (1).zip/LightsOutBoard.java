

// INSTRUCCIONES

// 1) Descargar el archivo
// 2) Abrir terminal
// 3) Navega a la carpeta donde se encuentra el archivo descargado utilizando el comando "cd"
// seguido de la ruta de la carpeta.
// 4) Ejecuta el archivo con el comando "java -jar" seguido del nombre del archivo con la extensión correspondiente. 


import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;

package juego;


public class LightsOutBoard {
    private boolean[][] board;
    private int numMoves;

    public LightsOutBoard(int size) {
        this.board = new boolean[size][size];
        this.numMoves = 0;

        // Inicializar el tablero con luces aleatorias encendidas
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                this.board[i][j] = random.nextBoolean();
            }
        }
    }

    public int getSize() {
        return this.board.length;
    }

    public boolean isLit(int row, int col) {
        return this.board[row][col];
    }

    public void select(int row, int col) {
        this.numMoves++;

        // Cambiar el estado de la luz seleccionada y las adyacentes
        this.toggle(row, col);
        if (row > 0) {
            this.toggle(row - 1, col);
        }
        if (row < this.board.length - 1) {
            this.toggle(row + 1, col);
        }
        if (col > 0) {
            this.toggle(row, col - 1);
        }
        if (col < this.board.length - 1) {
            this.toggle(row, col + 1);
        }
    }

    private void toggle(int row, int col) {
        this.board[row][col] = !this.board[row][col];
    }

    public boolean isComplete() {
        // Comprobar si todas las luces están encendidas
        for (int i = 0; i < this.board.length; i++) {
            for (int j = 0; j < this.board.length; j++) {
                if (!this.board[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    public int getNumMoves() {
        return this.numMoves;
    }
}

    

    
   package juego;



public class LightsOutScore {
    private ArrayList<Integer> scores;
    private int maxSize;

    public LightsOutScore(int maxSize) {
        this.scores = new ArrayList<>();
        this.maxSize = maxSize;
    }

    public void addScore(int score) {
        this.scores.add(score);
        Collections.sort(this.scores);

        if (this.scores.size() > this.maxSize) {
            this.scores.remove(0);
        }
    }

    public ArrayList<Integer> getScores() {
        return this.scores;
    }
}


        
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = e.getY() / (getHeight() / size);
                int col = e.getX() / (getWidth() / size);
                toggle(row, col);
            }
        });
    
    
    private void toggle(int row, int col) {
        lights[row][col] = !lights[row][col];
        if (row > 0) lights[row-1][col] = !lights[row-1][col];
        if (col > 0) lights[row][col-1] = !lights[row][col-1];
        if (row < size-1) lights[row+1][col] = !lights[row+1][col];
        if (col < size-1) lights[row][col+1] = !lights[row][col+1];
        moves++;
        repaint();
        checkWin();
    }
    
    private void checkWin() {
        boolean win = true;
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (!lights[row][col]) {
                    win = false;
                    break;
                }
            }
        }
        if (win) {
            highScores.add(new Score(size, moves));
            Collections.sort(highScores);
            if (highScores.size() > 10) {
                highScores.remove(highScores.size()-1);
            }
            reset();
        }
    
    
    }
    
    public void reset() {
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                lights[row][col] = true;
            }
        }
        for (int i = 0; i < size*size*2; i++) {
            int row = (int) (Math.random() * size);
            int col = (int) (Math.random() * size);
            toggle(row, col);
        }
        moves = 0;
        repaint();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int cellWidth = getWidth() / size;
        int cellHeight = getHeight() / size;
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                Color color = lights[row][col] ? Color.YELLOW : Color.BLACK;
                g.setColor(color);
                g.fillOval(col*cellWidth, row*cellHeight, cellWidth, cellHeight);
            }
        }
    }


public class LightsOutBoard {


    private int[][] presses;  // matriz para llevar la cuenta de las veces que se ha presionado cada casilla

    public LightsOutBoard(int size) {
    
        presses = new int[size][size];  // inicializar la matriz con ceros
    }

    public void toggle(int row, int col) {
        
        // incrementar el contador de la casilla correspondiente
        presses[row][col] += 1;
    }

}

